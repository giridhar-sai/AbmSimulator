
#include <stdio.h>
#include <ctype.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>


#define MPS 1024 //Max size of a p

struct KeyI{
	int linenumber;
	char k[20];
	char cmnd[1024];
};

struct couple
{
	struct KeyI Key_CommandPair[MPS];
	int currentpsize;
};

void initializePair(struct couple* p)
{
	p->currentpsize = 0;
}

void addcouple(struct couple* p, int linenumber, const char* k, const char* cmnd)
{
    	if (p->currentpsize < MPS)
	{
        	int index = p->currentpsize;
        	p->Key_CommandPair[index].linenumber = linenumber;
        	strncpy(p->Key_CommandPair[index].k, k, sizeof(p->Key_CommandPair[index].k));
		
		if(cmnd == NULL)
		{
			strcpy(p->Key_CommandPair[index].cmnd , "\0");
		}
		else
		{
			strncpy(p->Key_CommandPair[index].cmnd, cmnd, sizeof(p->Key_CommandPair[index].cmnd));
		}
		
		p->currentpsize++;
    	}
	else
	{
        	printf("Error: couple is full, cannot add more ps.\n");
    	}
}

int fetchlineno(struct couple* p, const char* k, const char* cmnd) 
{
    	for (int i = 0; i < p->currentpsize; i++)
	{
        	if (strcmp(p->Key_CommandPair[i].k, k) == 0 && strcmp(p->Key_CommandPair[i].cmnd, cmnd) == 0) 
		{
            		return p->Key_CommandPair[i].linenumber;
        	}
  	}
    return -1;
}

void DisplayPair(struct couple *p) 
{
    for (int i = 0; i < p->currentpsize; i++)
	{
		printf("Line Number: %d, Keyword: %s, Command: %s\n",p->Key_CommandPair[i].linenumber,p->Key_CommandPair[i].k,p->Key_CommandPair[i].cmnd);
    }
}

#define Maxsize 500 //Max size of a 2d array

struct Stringarray{
	char data[Maxsize][30];
	int currentsize;
};

void initializeStrings(struct Stringarray* array)
{
	array-> currentsize = 0;
}

int isEmptyStrings(struct Stringarray* array)
{
	return array->currentsize == 0;
}

int isFullStrings(struct Stringarray* array)
{
	return array->currentsize == Maxsize;
}

void append(struct Stringarray* array, const char* data)
{
	if(!isFullStrings(array))
	{
		strcpy(array->data[array->currentsize], data);
		array->currentsize++;
	}
	else
	{
		printf("String is full");
	}
}

char* atindex(struct Stringarray* array, int location)
{
	if(location>=0 && location < array->currentsize)
	{
		return array->data[location];
	}
	else
	{
		printf("Index Invalid \n");
		return NULL;
	}
}

char* addressofdata(struct Stringarray* array, const char* data)
{
	static char address[20];

	for(int i = 0; i<Maxsize; i++)
	{
		if(strcmp(array->data[i], data) == 0)
		{
			snprintf(address, sizeof(address), "%p", (void*)&(array->data[i]));
			return address;
		}
	}
	return NULL;
}

void printarray(struct Stringarray* array)
{
    for (int i = 0; i < array->currentsize; i++)
    {
        printf("Element %d: %s\n", i, array->data[i]);
    }
}



#define MaxMapsize 500 //Max map elements

struct addresstoval
{
	char address[30];
	int value;
};

struct Map
{
	struct addresstoval Mapitems[MaxMapsize];
	int currentsize;
};

void initializeMap(struct Map* map)
{
	map->currentsize = 0;
}

void insert(struct Map* map, const char* key, int value)
{
	for(int i = 0; i<MaxMapsize; i++)
    {
        if(strcmp(map->Mapitems[i].address, key) == 0)
        {
            map->Mapitems[i].value = value;
			return;
        }
    }

	if(map->currentsize < MaxMapsize)
	{
		strcpy(map->Mapitems[map->currentsize].address, key);
		map->Mapitems[map->currentsize].value = value;
		map->currentsize++;
 	}
}

int find(struct Map* map, const char* key)
{
	if(key != NULL)
	{
		for(int i = 0; i < MaxMapsize; i++)
		{
			if(strcmp(map->Mapitems[i].address, key) == 0)
			{
				return map->Mapitems[i].value;
			}
		}
	}
	return INT_MIN;
}

void printMap(struct Map *map)
{
    for (int i = 0; i < map->currentsize; i++)
	{
        printf("Address: %s, Value: %d\n", map->Mapitems[i].address, map->Mapitems[i].value);
    }
}



#define MaxSize 100

struct valueHolder
{
	int ReceptacleNumber;
	struct Stringarray variablenames[MaxSize];
	struct Map variablevalues[MaxSize];
};

int inContainerAddress(struct valueHolder* Receptacle, const char* variableaddress)
{
	int index = Receptacle->ReceptacleNumber;
	return find(&(Receptacle->variablevalues[index]), variableaddress);
}


void initCont(struct valueHolder* Receptacle)
{
	 Receptacle->ReceptacleNumber = 0;
	 initializeStrings(&(Receptacle->variablenames[0]));
	 initializeMap(&(Receptacle->variablevalues[0]));
}

void getintoCont(struct valueHolder* Receptacle, const char* variablename, int variablevalue)
{
	if(Receptacle->ReceptacleNumber < MaxSize)
	{
		int index = Receptacle->ReceptacleNumber;
		append(&(Receptacle->variablenames[index]), variablename);
		insert(&(Receptacle->variablevalues[index]), addressofdata(&(Receptacle->variablenames[index]), variablename), variablevalue);
	}
	else
	{
		printf("it is full");
	}
}

void contUpdt(struct valueHolder* Receptacle, const char* variableaddress, int variablevalue)
{
		int index = Receptacle->ReceptacleNumber;
		if(inContainerAddress(Receptacle, variableaddress) != -1)
		{
			insert(&(Receptacle->variablevalues[index]), variableaddress, variablevalue);
		}
}

int inAboveFind(struct valueHolder* Receptacle, const char* variablename)
{
	int index = (Receptacle->ReceptacleNumber > 0)? Receptacle->ReceptacleNumber - 1 : -1;
	if(index != -1)
	{
		return find(&(Receptacle->variablevalues[index]), addressofdata(&(Receptacle->variablenames[index]), variablename));
	}
	else
	{
		return INT_MIN;
	}
}

int FindInContainer(struct valueHolder* Receptacle, const char* variablename)
{
	int index = Receptacle->ReceptacleNumber;
	return find(&(Receptacle->variablevalues[index]), addressofdata(&(Receptacle->variablenames[index]), variablename));
}


char* addressfrmCont(struct valueHolder* Receptacle, const char* variablename)
{
	int index = Receptacle->ReceptacleNumber;
	return addressofdata(&(Receptacle->variablenames[index]), variablename);
}

void gettingScope(struct valueHolder* Receptacle)
{
		Receptacle->ReceptacleNumber++;
}

void removeScope(struct valueHolder* Receptacle)
{
	int index = Receptacle->ReceptacleNumber;
	initializeStrings(&(Receptacle->variablenames[index]));
	initializeMap(&(Receptacle->variablevalues[index]));
	Receptacle->ReceptacleNumber--;
}

void returnAddresses(struct valueHolder* Receptacle, int numofreturnables)
{
	int currentindex = Receptacle->ReceptacleNumber;
	int indextoappendin = Receptacle->ReceptacleNumber - 1;

	for(int i = Receptacle->variablenames[currentindex].currentsize-1; i >= Receptacle->variablenames[currentindex].currentsize-numofreturnables; i--)
	{
		if(addressofdata(&(Receptacle->variablenames[indextoappendin]), Receptacle->variablenames[currentindex].data[i]) != NULL )
		{
				insert(&(Receptacle->variablevalues[indextoappendin]), addressofdata(&(Receptacle->variablenames[indextoappendin]), Receptacle->variablenames[currentindex].data[i]), find(&(Receptacle->variablevalues[currentindex]),addressofdata(&(Receptacle->variablenames[currentindex]), Receptacle->variablenames[currentindex].data[i])));
		}
		else
		{
			append(&(Receptacle->variablenames[indextoappendin]), Receptacle->variablenames[currentindex].data[i]);
			insert(&(Receptacle->variablevalues[indextoappendin]), addressofdata(&(Receptacle->variablenames[indextoappendin]), Receptacle->variablenames[currentindex].data[i]), find(&(Receptacle->variablevalues[currentindex]),addressofdata(&(Receptacle->variablenames[currentindex]), Receptacle->variablenames[currentindex].data[i])));
		}
	}
}

void displayCont(struct valueHolder* Receptacle)
{
	for(int i = 0; i <= Receptacle-> ReceptacleNumber; i++)
	{
		printf("current scope: %d\n", i);
		printarray(&(Receptacle->variablenames[i]));
		printMap(&(Receptacle->variablevalues[i]));
		printf("\n");
	}
}

#define StackSize 100 //Max stack elements

struct CharStack
{
        int top;
        char* stackitems[StackSize];
};


void initialize(struct CharStack* stack)
{
	stack->top = -1;
}

int isEmpty(struct CharStack* stack)
{
	return stack->top == -1;
}

int IsFull(struct CharStack* stack)
{
	return stack->top == StackSize-1;
}

void PushIntoStack(struct CharStack* stack, const char* item)
{
	if(IsFull(stack))
	{
		printf("Stack is full.....\n ");
		return;
	}
	stack->stackitems[++stack->top] = strdup(item);
}

char* PopOpr(struct CharStack* stack)
{
	if(isEmpty(stack))
	{
		printf("stack is empty... nothing to pop \n");
		return '\0';
	}
	char* popitem = stack->stackitems[stack->top];
	stack->top--;
	return popitem;
}

char* PeekStack(struct CharStack* stack)
{
	if(isEmpty(stack))
    {
            printf("stack is empty... nothing to pop \n");
            return '\0';
    }
	return stack->stackitems[stack->top];
}

void PrintStack(struct CharStack* stack)
{
	if(isEmpty(stack))
	{
		printf("Stack is empty....\n");
		return;
	}
	printf("Stack contents: ");
	for(int i = 0; i<= stack->top; i++)
	{
		printf("%s, ", stack->stackitems[i]);
	}
	printf(" -- done \n");
}


FILE* abmReader(const char* filename){
	FILE* file = fopen(filename, "r"); //opens the given file
	if(file == NULL)
	{
		perror("error opening the abm file please check and input again.");
		return NULL;
	}
	return file; //return file
}



void PrintabmFile(FILE* abmFile)
{
	if(abmFile == NULL)
	{
		 perror("error opening the abm file please check and input again.");
                return;
	}
	char buffer[1024];

	while(fgets(buffer, sizeof(buffer), abmFile) != NULL)
	{
		printf("%s", buffer);
	}
}


void trimleadtrailspaces(char *line)
{
    if(line == NULL)
    {
	     return;
    }

  
    char *start = line;

    
    while(isspace(*start))
    {
	     start++; 
    }

    
    if(*line == '\0')
    {
	     return;
    }

    
    char *endchar = line + strlen(line) - 1;

   
    while(endchar > line && isspace(*endchar))
    {
	     endchar--; 
    }

    *(endchar + 1) = '\0';

    if(start != line)
    {
	      memmove(line, start, strlen(start) + 1); 
    }
}



void abmkeywordhelper(struct couple* p, struct CharStack* stack, struct valueHolder* Receptacle, struct Map* labellocations)
{
    bool Beginevoked = false;
    bool Callevoked = false;
    bool Returnedfromcall = false;

    int numberofbegins = 0;
    int numberofcalls = 0;

    struct CharStack lastcontrol;
    initialize(&lastcontrol); 

    int returnables = 0; 

    for (int i = 0; i < p->currentpsize; i++)
    {
        char *k = p->Key_CommandPair[i].k; 
        char *cmnd = p->Key_CommandPair[i].cmnd; 

        if(strcmp(k, "show") == 0) 
        {
            printf("%s\n", cmnd);
        }
        else if (strcmp(k, "print") == 0) 
        {
            char *peek = PeekStack(stack);
            (peek != NULL) ? printf("%s\n", peek) : printf("no element in stack to peek\n");
        }
        else if (strcmp(k, "pop") == 0) 
        {
            PopOpr(stack);
        }
        else if (strcmp(k, "push") == 0) 
        {
            PushIntoStack(stack, cmnd);
        }
        else if (*k == '-') 
        {
            int right = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            int left = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            int result = left - right; 
            char resulttochar[10];
            sprintf(resulttochar, "%d", result); 
            PushIntoStack(stack, resulttochar); 
        }
        else if (*k == '+')
        {
            int right = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            int left = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            int result = left + right;
            char resulttochar[10];
            sprintf(resulttochar, "%d", result);
            PushIntoStack(stack, resulttochar);
        }
        else if (*k == '*')
        {
            int right = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            int left = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            int result = left * right;
            char resulttochar[10];
            sprintf(resulttochar, "%d", result);
            PushIntoStack(stack, resulttochar);
        }
        else if (*k == '/')
        {
            int right = !isEmpty(stack) ? atoi(PopOpr(stack)) : 1;
            int left = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            int result = left / right;
            char resulttochar[10];
            sprintf(resulttochar, "%d", result);
            PushIntoStack(stack, resulttochar);
        }
        else if (strcmp(k, "div") == 0) 
        {
            int right = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            int left = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            int result = left % right;
            char resulttochar[10];
            sprintf(resulttochar, "%d", result);
            PushIntoStack(stack, resulttochar);
        }
        else if (*k == '&') 
        {
            int right = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            int left = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            bool result = ((left == 1) ? true : false) & ((right == 1) ? true : false);
            PushIntoStack(stack, result ? "1" : "0"); 
        }
        else if (*k == '|')
        {
            int right = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            int left = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            bool result = ((left == 1) ? true : false) | ((right == 1) ? true : false);
            PushIntoStack(stack, result ? "1" : "0"); 
        }
        else if (*k == '!')
        {
            int argument = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            bool result = ((argument == 1) ? false : true);
            PushIntoStack(stack, result ? "1" : "0");
        }
        else if (strcmp(k, "<>") == 0)
        {
            int right = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            int left = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            bool result = (left != right);
            PushIntoStack(stack, result ? "1" : "0");
        }
        else if (strcmp(k, "<=") == 0)
        {
            int right = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            int left = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            bool result = left <= right;
            PushIntoStack(stack, result ? "1" : "0");
        }
        else if (strcmp(k, ">=") == 0)
        {
            int right = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            int left = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            bool result = left >= right;
            PushIntoStack(stack, result ? "1" : "0");
        }
        else if (strcmp(k, "<") == 0)
        {
            int right = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            int left = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            bool result = left < right;
            PushIntoStack(stack, result ? "1" : "0");
        }
        else if (strcmp(k, ">") == 0)
        {
            int right = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            int left = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            bool result = left > right;
            PushIntoStack(stack, result ? "1" : "0");
        }
        else if (strcmp(k, "rvalue") == 0)
        {
            if((Beginevoked && !Callevoked) || (numberofbegins != numberofcalls))
            {
                if(inAboveFind(Receptacle, cmnd) != INT_MIN)
                {
                    int value = inAboveFind(Receptacle, cmnd);
                    char charvalue[10];
                    sprintf(charvalue, "%d", value);
                    PushIntoStack(stack, charvalue);
                }
                else if(FindInContainer(Receptacle, cmnd) != INT_MIN)
                {
                    int value = FindInContainer(Receptacle, cmnd);
                    char charvalue[10];
                    sprintf(charvalue, "%d", value);
                    PushIntoStack(stack, charvalue);
                }
                else
                {
                    getintoCont(Receptacle, cmnd, 0);
                    PushIntoStack(stack, "0");
                }
            }
            else
            {
                if(FindInContainer(Receptacle, cmnd) != INT_MIN)
                {
                    int value = FindInContainer(Receptacle, cmnd);
                    char charvalue[10];
                    sprintf(charvalue, "%d", value);
                    PushIntoStack(stack, charvalue);
                }
                else
                {
                    getintoCont(Receptacle, cmnd, 0);
                    PushIntoStack(stack, "0");
                }
            }
        }
        else if (strcmp(k, "lvalue") == 0)
        {
            if (FindInContainer(Receptacle, cmnd) != INT_MIN)
            {
                PushIntoStack(stack, addressfrmCont(Receptacle, cmnd));
            }
            else
            {
                getintoCont(Receptacle, cmnd, 0);
                PushIntoStack(stack, addressfrmCont(Receptacle, cmnd));
            }
            if(Returnedfromcall == true && Beginevoked == true)
            {
                returnables++;
            }
        }
        else if (strcmp(k, ":=") == 0)
        {
            int value = !isEmpty(stack) ? atoi(PopOpr(stack)) : 0;
            char *address = !isEmpty(stack) ? PeekStack(stack) : NULL;
            if (inContainerAddress(Receptacle, address) != INT_MIN)
            {
                contUpdt(Receptacle, address, value);
                PopOpr(stack);
            }
            else
            {
                printf("given l value never encountered...\n");
            }
        }
        else if (strcmp(k, "copy") == 0)
        {
            PushIntoStack(stack, PeekStack(stack));
        }
        else if (strcmp(k, "label") == 0)
        {
            char key[100]="";
            if(find(labellocations,strcat(strcat(strcat(key, k), " "), cmnd)) != INT_MIN)
            {
                continue;
            }
            else
            {
                printf("label asked is not in given map, failed \n");
                return;
            }
        }
        else if (strcmp(k, "call") == 0)
        {
            char key[100]= "";
            strcat(strcat(strcat(key, "label"), " "), cmnd);
            int index = find(labellocations, key);
            char numtochar[10];
            sprintf(numtochar, "%d", i);
            PushIntoStack(&lastcontrol, numtochar);
            Callevoked = true;
            numberofcalls++;
            i = index;
        }
        else if(strcmp(k, "return") == 0)
        {
            Returnedfromcall = true;
            numberofcalls--;
            if(numberofcalls == 0)
            {
                numberofcalls = false;
            }
            int lastcontrolindex = atoi(PopOpr(&lastcontrol));
            i = lastcontrolindex;
        }
        else if(strcmp(k, "begin") == 0)
        {
            Beginevoked = true;
            gettingScope(Receptacle);
            numberofbegins++;
        }
        else if(strcmp(k, "end") == 0)
        {
            if(returnables > 0)
            {
                returnAddresses(Receptacle, returnables);
                returnables = 0;
            }
            removeScope(Receptacle);
            numberofbegins--;
            if(numberofbegins == 0)
            {
                Beginevoked = false;
            }
        }
        else if(strcmp(k, "goto") == 0)
        {
            char key[100]= "";
            strcat(strcat(strcat(key, "label"), " "), cmnd);
            int index = find(labellocations, key);
            i=index;
        }
        else if(strcmp(k, "gofalse") == 0)
        {
            char* temp = PopOpr(stack);
            if(strcmp(temp, "0") == 0)
            {
                char key[100]= "";
                strcat(strcat(strcat(key, "label"), " "), cmnd);
                int index = find(labellocations, key);
                i=index;
            }
        }
        else if(strcmp(k, "gotrue") == 0)
        {
            char* temp = PopOpr(stack);
            if(strcmp(temp, "0") != 0)
            {
                char key[100]= "";
                strcat(strcat(strcat(key, "label"), " "), cmnd);
                int index = find(labellocations, key);
                i=index;
            }
        }
        else if(strcmp(k, "halt") == 0)
        {
            exit(0);
            return;
        }
   }
}



void abminstructionrunner(FILE* abminstructionfile)
{
    if (abminstructionfile == NULL)
    {
        perror("Error opening file");
        return;
    }

    char Eachline[1024];
    char *firstspace;
    char *k;
    char *cmnd;

    struct couple p;
    struct Map labellocations;
    struct CharStack stack;
    struct valueHolder Receptacle;

    int linenumber = 0;

    initializePair(&p);
    initializeMap(&labellocations);
    initialize(&stack);
    initCont(&Receptacle);

    while (fgets(Eachline, sizeof(Eachline), abminstructionfile) != NULL)
    {
        trimleadtrailspaces(Eachline);
        firstspace = strchr(Eachline, ' ');

        if (firstspace != NULL)
        {
            *firstspace = '\0';
            k = Eachline;
            cmnd = firstspace + 1;
        }
        else
        {
            k = Eachline;
            cmnd = NULL;
        }

        trimleadtrailspaces(k);
        trimleadtrailspaces(cmnd);

        if((int)*k != 0)
        {
            addcouple(&p, linenumber, k, cmnd);
            if(strcmp(k, "label") == 0)
            {
                char key[100] = "";
                strcat(strcat(strcat(key, k), " "), cmnd);
                insert(&labellocations,key,linenumber);
            }
            linenumber++;
        }
    }
    abmkeywordhelper(&p, &stack, &Receptacle, &labellocations);
}


//Main FILE thats runs all the abm files given to produce output.
int main(int argc, char* argv[])
{
		if(argv[1] != NULL)
		{
			FILE* abmFile = abmReader(argv[1]);
			abminstructionrunner(abmFile);
		}
		else
		{
			printf("NO FILE NAME EVER ENTERED\n");
		}

	return 0; //just to exit
}
